import { table, column } from "./Decorator";
import { Table } from "./Table";
import { ColumnType } from "./ColumnType";

@table('a4a87f28374792e6a550e84b71419e688e254741cedae57c8cb0fc0f0a895dbf')
export class a4a87f28374792e6a550e84b71419e688e254741cedae57c8cb0fc0f0a895dbf extends Table {
    @column(ColumnType.STRING | ColumnType.PRIMARY)
    cbf0eebae0e30afd50bc051d7d56e51e43fa323d8550e84b4b4f6702: string;
    @column(ColumnType.STRING)
    a9dd99d4d4cfd5ab89cf6005caedb6e6307d4743c40953bf9abe0fdd: string;
}

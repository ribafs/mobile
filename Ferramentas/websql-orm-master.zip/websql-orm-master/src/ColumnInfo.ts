import { ColumnType } from "./ColumnType";

/**
 * 列信息 
 * */
export class ColumnInfo {
    name: string;
    type: ColumnType;
}
// var http = require( 'http' );

// var server =http.createServer( function ( request ,response ){
//           response.end( 'Hi' );
// } );
// server.listen( 8000 );
// console.log( 'HTTP服务器启动中，端口：8000.....' );
/**
 * @fileoverview About this file
 */

ydn.debug.log('ydn.db', 'info');

/**
 * @externs ydn.db.Storage
 */


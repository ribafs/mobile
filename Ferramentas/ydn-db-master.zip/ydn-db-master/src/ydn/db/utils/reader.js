/**
 * @fileoverview About this file.
 *
 * User: kyawtun
 * Date: 17/1/13
 */

goog.provide('ydn.db.io.Reader');


/**
 * Read delimited records from a URL.
 * @param {string} url
 * @constructor
 */
ydn.db.io.Reader = function(url) {

};


ydn.db.io.Reader.prototype.next = function() {

};
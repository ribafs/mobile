

goog.provide('ydn.db.schema.fulltext.Entry');



/**
 * @interface
 */
ydn.db.schema.fulltext.Entry = function() {};




